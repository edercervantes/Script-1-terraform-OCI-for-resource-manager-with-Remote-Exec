# Script-1-terraform-OCI-for-resource-manager-with-Remote-Exec

This folder is designed to accompany the [Oracle Python4ATP HOL](https://github.com/edercervantes/learning-library/tree/master/workshops/python4atp).

**Instructions for running the folder**

- All you need to do is download the zip file from this repository.

-For debugging, see the following resources:

[FAQ for the Oracle Cloud Infrastructure Terraform provider](https://www.terraform.io/docs/providers/oci/guides/faq.html)

[Oracle Cloud Infrastructure Provider](https://www.terraform.io/docs/providers/oci/index.html)